/* Prototypes for functions defined in
xardummy.c
 */

void XCallHook(struct XarSubIO * , long , char * );

int __asm __saveds __UserLibInit(register __a6 struct Library * );

void __asm __saveds __UserLibCleanup(register __a6 struct Library * );

void * XAllocMem(void * , ULONG );

void XFreeMem(void * , void * );

long ScanArchive(struct XarSubHandle * );

long FCopy(BPTR , BPTR , ULONG );

int ToUpper(int );

int StringICmp(UBYTE const * , UBYTE const * );

struct XarSubInfo * __saveds XarsArchiverInfo(void);

long __asm __saveds XarsCreateArchive(register __a0 struct XarSubHandle * );

long __asm __saveds XarsOpenArchive(register __a0 struct XarSubHandle * );

long __asm __saveds XarsCloseArchive(register __a0 struct XarSubHandle * );

long __asm __saveds XarsAddFile(register __a0 struct XarSubHandle * , register __a1 struct XarSubIO * , register __a2 struct XarSubLock ** );

long __asm __saveds XarsExtractFile(register __a0 struct XarSubLock * , register __a1 struct XarSubIO * );

long __asm __saveds XarsDeleteFile(register __a0 struct XarSubLock * );

long __asm __saveds XarsCopyFile(register __a0 struct XarSubLock ** , register __a1 struct XarSubHandle * );

long __asm __saveds XarsPackArchive(register __a0 struct XarSubHandle * , register __a1 struct XarSubHandle * );

long __asm __saveds XarsModifyFileData(register __a0 struct XarSubLock * , register __a1 struct FileData * );

long __asm __saveds XarsSetFilenote(register __a0 struct XarSubLock * , register __a1 UBYTE * );

long __asm __saveds XarsRenameFile(register __a0 struct XarSubLock * , register __a1 UBYTE * , register __d0 long );

long __asm __saveds XarsNextGeneration(register __a0 struct XarSubLock * );

long __asm __saveds XarsExamine(register __a0 struct XarSubLock * , register __a1 struct XpkFib * );

long __asm __saveds XarsUndeleteFile(register __a0 struct XarSubLock * );

long __asm __saveds XarsCmpFilename(register __a0 UBYTE * , register __a1 UBYTE * );

