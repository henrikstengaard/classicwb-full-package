#include <stdlib.h>
#include <stdio.h>

#include <libraries/xpkarchive.h>

struct Library *XpkArchiveBase;

main(int argc,char *argv[])
{
   char *p;
   int gen=0;
   XarHandle *arc;
   LONG Error;

   XpkArchiveBase=OpenLibrary("xpkarctest.library",2);
   if(!XpkArchiveBase) {
      fprintf(stderr,"Cannot open xpkarctest.library\n");
      exit(0);
   }

   if(argc!=4) {
      fprintf(stderr,"Usage: %s <arc> <name> <newnote>\n",argv[0]);
      goto fail1;
   }

   if(!(arc=XarOpenArchive(XAR_ArchiveName,argv[1],
                           XAR_Error,&Error,TAG_DONE))) {
      fprintf(stderr,"Cannot open source archive.Error: %ld\n",Error);
      goto fail1;
   }


   if(p=rindex(argv[2],',')) {
      *p=0;
      sscanf(p+1,"%d",&gen);
      gen--;
   }

   printf("%s,%d\n",argv[2],gen+1);

   printf("R: %ld\n",XarSetFileNote(XAR_Archive,arc,
                               XAR_FileName,argv[2],
                               XAR_Generation,gen,
                               XAR_FileNote,argv[3],
                               TAG_DONE));

   XarCloseArchive(arc);
fail1:
   CloseLibrary(XpkArchiveBase);
   exit(0);

}

