#include <stdlib.h>
#include <stdio.h>

#include <libraries/xpkarchive.h>

struct Library *XpkArchiveBase;

char srcname[41],dstname[41],tmp[41];

char *filenote=NULL;

main(int argc,char *argv[])
{
   int a;
   XarHandle *src,*dst;
   LONG Error;

   XpkArchiveBase=OpenLibrary("xpkarctest.library",1);
   if(!XpkArchiveBase) {
      fprintf(stderr,"Cannot open xpkarctest.library\n");
      exit(0);
   }

   if(argc<4) {
      fprintf(stderr,"Usage: %s <src_arc> <dst_arc> [+note] <file1[,gen]>#<out1[,gen]> [<file2>#<out2> ...]\n",argv[0]);
      goto fail1;
   }

   if(!(src=XarOpenArchive(XAR_ArchiveName,argv[1],
                           XAR_Error,&Error,TAG_DONE))) {
      fprintf(stderr,"Cannot open source archive.Error: %ld\n",Error);
      goto fail1;
   }

   if(!(dst=XarOpenArchive(XAR_ArchiveName,argv[2],
                           XAR_ArchiveMode,XAR_ModeAppend,
                           XAR_Error,&Error,TAG_DONE))) {
      fprintf(stderr,"Cannot open source archive.Error: %ld\n",Error);
      goto fail2;
   }


   for(a=3;a<argc;a++) {
      int srcgen=1,dstgen=1;

      if(argv[a][0]=='+') {
         filenote=&argv[a][1];
         continue;
      }

      switch(sscanf(argv[a],"%40[^#]#%40s",srcname,dstname)) {

         case 0: fprintf(stderr,"internal error\n");
                 goto fail3;
                 break;

         case 1: strcpy(tmp,srcname);
                 sscanf(tmp,"%40[^,],%d",srcname,&srcgen);
                 strcpy(dstname,srcname);
                 dstgen=srcgen;
                 break;
         case 2: strcpy(tmp,srcname);
                 sscanf(tmp,"%40[^,],%d",srcname,&srcgen);
                 dstgen=srcgen;
                 strcpy(tmp,dstname);
                 sscanf(tmp,"%40[^,],%d",dstname,&dstgen);
                 break;
      }

      if(srcgen>0) srcgen--;
      if(dstgen>0) dstgen--;

      printf("Generation %d of %s -> %d of %s\n",srcgen+1,srcname,
                                                    dstgen+1,dstname);

      XarCopyFile(XAR_Archive,src,XAR_DestArchive,dst,
                  XAR_FileName,srcname,XAR_Generation,srcgen,
                  XAR_NewName,dstname,XAR_NewGeneration,dstgen,
                  XAR_AutoNextGen,0,XAR_FileNote,filenote,
                  XAR_Error,&Error,TAG_DONE);

      if(Error>=XARERROR_LEVEL) {
         fprintf(stderr,"Fatal Error: %ld\n",Error);
         break;
      }
   }

fail3:
   XarCloseArchive(dst);
fail2:
   XarCloseArchive(src);
fail1:
   CloseLibrary(XpkArchiveBase);
   exit(0);

}













