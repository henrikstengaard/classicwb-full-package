#include <exec/types.h>
#include <exec/memory.h>
#include <dos/dos.h>
#include <pragma/exec_lib.h>

#include "dossupport.h"
#include <string.h>

void *dosalloc(LONG size)
{
   register LONG *mem;

   if(mem = AllocMem(size += 4, MEMF_PUBLIC|MEMF_CLEAR))
     *mem++ = size;

   return mem;
}

void dosfree(void *mem)
{
   if(mem)
   {
      mem = (ULONG *)mem - 1;
      FreeMem(mem, *(ULONG *)mem);
   }
}

BSTR cstr2b(STRPTR cstr, STRPTR buf)
{
  register UBYTE len;
   
  *buf = len = strlen(cstr);
  strncpy(buf+1,cstr,len);
  return (BSTR) ((ULONG)buf >> 2);
}

STRPTR bstr2c(BSTR bstr, STRPTR buf)
{
   register UBYTE len;
   register STRPTR p;
   
   p = (STRPTR)(bstr << 2);
   len = *p++;
   strncpy(buf, p, len);
   buf[len] = '\0';
   return (STRPTR) buf;
}

STRPTR bstr2cinplace(STRPTR pp)
{
   register UBYTE len;
   register STRPTR p = pp;
   
   for(len = *p; len--; p++)
     p[0] = p[1];
   *p = '\0';
   return (STRPTR) pp;
}

BSTR cstr2binplace(STRPTR pp)
{
   register UBYTE len;
   register STRPTR p = pp;
   
   len = strlen(p);
   for(p = pp+len; p != pp; --p)
     *p = *(p-1);
   *pp=len;

   return (BSTR)((ULONG)pp >> 2);
}

