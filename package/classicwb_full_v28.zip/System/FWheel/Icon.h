BOOL MatchToolType(char *tooltype,char *value);
char *GetStringToolType(char *tooltype);
int GetNumericToolType(char *tooltype,int defvalue);
BOOL Icon_Setup();
void Icon_Cleanup();

extern struct DiskObject *MyDiskObject;


